import { Metadata } from "next"
import Link from "next/link"
import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion"
import { Sparkles, HelpCircle, ArrowRight } from "lucide-react"

export const metadata: Metadata = {
  title: "FAQ | Moonboy Studio",
  description: "Frequently asked questions about Moonboy Studio services, pricing, and workflow.",
}

const faqCategories = [
  {
    category: "Getting Started",
    questions: [
      {
        question: "How do I start a project with Moonboy Studio?",
        answer: "Starting is easy! Join our Discord server and open a ticket or DM us directly. Tell us about your project, and we will discuss requirements, timeline, and pricing. Once everything is agreed upon, we will get started right away.",
      },
      {
        question: "Why do you work through Discord?",
        answer: "Discord is where our community lives! It allows for real-time communication, easy file sharing, and quick feedback loops. Plus, most of our clients are already active on Discord, making collaboration seamless and natural.",
      },
      {
        question: "Do I need to pay upfront?",
        answer: "For most projects, we require a 50% deposit upfront with the remaining 50% due upon completion. For subscriptions and smaller projects, we may offer different payment terms. We accept PayPal, credit cards, and cryptocurrency.",
      },
    ],
  },
  {
    category: "Services & Delivery",
    questions: [
      {
        question: "How long does a typical project take?",
        answer: "It depends on the service and complexity. Basic projects typically take 2-3 days, standard projects 3-5 days, and premium/complex projects 5-10 days. We always provide estimated timelines before starting and keep you updated on progress.",
      },
      {
        question: "Do you offer revisions?",
        answer: "Yes! Every package includes revisions. Basic packages include 1-2 revisions, standard packages include 3 revisions, and premium packages include unlimited revisions. We want you to be completely satisfied with the final result.",
      },
      {
        question: "What if I am not satisfied with the work?",
        answer: "We work closely with you throughout the project to ensure satisfaction. If something is not right, we will make it right through revisions. In rare cases where we cannot meet your expectations, we offer partial or full refunds depending on the situation.",
      },
      {
        question: "Do I get the source files?",
        answer: "Yes! For design projects, you receive all source files (PSD, AI, Figma links, etc.). For websites, you get full access to the code repository. For video projects, we can provide project files upon request for an additional fee.",
      },
    ],
  },
  {
    category: "Pricing & Payments",
    questions: [
      {
        question: "How do payments work?",
        answer: "We accept PayPal, credit/debit cards, and various cryptocurrencies. For projects over $200, we typically split payments into 50% upfront and 50% upon completion. Subscriptions are billed monthly at the start of each billing period.",
      },
      {
        question: "Can I get a custom quote?",
        answer: "Absolutely! Our listed prices are starting points. Every project is unique, and we are happy to provide custom quotes based on your specific needs. Just reach out on Discord and tell us what you are looking for.",
      },
      {
        question: "Do you offer discounts for multiple projects?",
        answer: "Yes! We offer bundle discounts when you combine multiple services. We also have special rates for returning clients and long-term partnerships. Ask us about loyalty discounts!",
      },
    ],
  },
  {
    category: "Technical Questions",
    questions: [
      {
        question: "What technologies do you use for websites?",
        answer: "We primarily use modern technologies like Next.js, React, and Tailwind CSS. For simpler sites, we might use static site generators or WordPress depending on your needs. We always choose the best tool for your specific project.",
      },
      {
        question: "Can you help with hosting and maintenance?",
        answer: "Yes! We can help you set up hosting on platforms like Vercel, Netlify, or traditional hosting providers. We also offer ongoing maintenance packages to keep your site updated and secure.",
      },
      {
        question: "What Discord bots do you work with?",
        answer: "We work with popular bots like MEE6, Carl-bot, Dyno, and many others. We can also develop custom bots for specific functionality. Our team stays updated on the latest Discord features and bot capabilities.",
      },
    ],
  },
]

export default function FAQPage() {
  return (
    <main className="min-h-screen bg-background">
      <Navigation />

      {/* Hero Section */}
      <section className="pt-32 pb-16 relative">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-primary/10 via-background to-background" />
        <div className="relative z-10 mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 text-center">
          <Badge variant="secondary" className="mb-4">
            <Sparkles className="h-3 w-3 mr-1" />
            Support
          </Badge>
          <h1 className="font-[family-name:var(--font-display)] text-4xl sm:text-5xl font-bold mb-6">
            Frequently Asked <span className="text-primary">Questions</span>
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Got questions? We have got answers. If you cannot find what you are looking for, feel free to reach out on Discord.
          </p>
        </div>
      </section>

      {/* FAQ Content */}
      <section className="py-16">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {faqCategories.map((category) => (
            <div key={category.category} className="mb-12">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 rounded-xl bg-primary/10 border border-primary/30 flex items-center justify-center">
                  <HelpCircle className="h-5 w-5 text-primary" />
                </div>
                <h2 className="font-[family-name:var(--font-display)] text-xl font-semibold">
                  {category.category}
                </h2>
              </div>
              <Accordion type="single" collapsible className="space-y-4">
                {category.questions.map((faq, index) => (
                  <AccordionItem
                    key={index}
                    value={`${category.category}-${index}`}
                    className="rounded-xl border border-border/50 bg-card/50 px-6 data-[state=open]:border-primary/30"
                  >
                    <AccordionTrigger className="text-left hover:no-underline py-4">
                      <span className="font-medium">{faq.question}</span>
                    </AccordionTrigger>
                    <AccordionContent className="text-muted-foreground pb-4 leading-relaxed">
                      {faq.answer}
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            </div>
          ))}
        </div>
      </section>

      {/* Still Have Questions */}
      <section className="py-20 bg-card/30">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="font-[family-name:var(--font-display)] text-2xl sm:text-3xl font-bold mb-4">
            Still Have Questions?
          </h2>
          <p className="text-muted-foreground mb-8 max-w-xl mx-auto">
            Cannot find the answer you are looking for? Our team is here to help. Join our Discord and ask us anything!
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Button size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90 gap-2" asChild>
              <a href="https://discord.gg" target="_blank" rel="noopener noreferrer">
                Ask on Discord
                <ArrowRight className="h-4 w-4" />
              </a>
            </Button>
            <Button size="lg" variant="outline" asChild>
              <Link href="/pricing">View Pricing</Link>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </main>
  )
}
