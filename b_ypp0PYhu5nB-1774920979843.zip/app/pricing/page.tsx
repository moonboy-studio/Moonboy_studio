import { Metadata } from "next"
import Link from "next/link"
import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Check, ArrowRight, Sparkles, Package, Zap, Crown, Infinity } from "lucide-react"

export const metadata: Metadata = {
  title: "Pricing | Moonboy Studio",
  description: "Transparent pricing for website development, graphic design, video editing, and Discord server setup services.",
}

const packages = [
  {
    name: "Starter Pack",
    icon: Zap,
    price: "$79",
    period: "one-time",
    description: "Perfect for small, one-off projects",
    features: [
      "1 service (basic level)",
      "Limited revisions",
      "Standard delivery time",
      "Discord support",
    ],
    cta: "Get Started",
    highlighted: false,
  },
  {
    name: "Pro Pack",
    icon: Crown,
    price: "$299",
    period: "one-time",
    description: "Best value for growing projects",
    features: [
      "2-3 services bundled",
      "Priority delivery",
      "More revisions included",
      "Dedicated support channel",
      "Source files included",
    ],
    cta: "Most Popular",
    highlighted: true,
  },
  {
    name: "Premium Pack",
    icon: Package,
    price: "$599+",
    period: "one-time",
    description: "Full-service digital transformation",
    features: [
      "Website + Design + Discord",
      "Fastest delivery times",
      "Unlimited revisions",
      "Priority queue access",
      "Dedicated project manager",
      "1 month of support",
    ],
    cta: "Contact Us",
    highlighted: false,
  },
]

const bundles = [
  {
    name: "Tournament Kit",
    description: "Everything you need to run a professional tournament",
    price: "$449",
    savings: "Save $120",
    includes: ["Tournament Website", "Event Posters (3)", "Discord Server Setup"],
    image: "https://images.unsplash.com/photo-1542751371-adc38448a05e?w=400&q=80",
  },
  {
    name: "Creator Pack",
    description: "Launch your content creator brand",
    price: "$279",
    savings: "Save $80",
    includes: ["Full Branding Kit", "Video Intro/Outro", "Social Media Templates"],
    image: "https://images.unsplash.com/photo-1598550476439-6847785fcea6?w=400&q=80",
  },
  {
    name: "Startup Launch Pack",
    description: "Get your business online with a professional presence",
    price: "$399",
    savings: "Save $100",
    includes: ["Multi-page Website", "Logo + Branding", "Social Media Setup"],
    image: "https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=400&q=80",
  },
]

const subscriptions = [
  {
    name: "Starter Sub",
    price: "$49",
    period: "/month",
    features: ["2 small requests/month", "48h response time", "Basic support"],
  },
  {
    name: "Pro Sub",
    price: "$149",
    period: "/month",
    features: ["5 requests/month", "Priority queue", "24h response time", "Dedicated channel"],
    popular: true,
  },
  {
    name: "Elite Sub",
    price: "$349",
    period: "/month",
    features: ["Unlimited requests (fair use)", "Same-day starts", "VIP support", "Strategy calls"],
  },
]

export default function PricingPage() {
  return (
    <main className="min-h-screen bg-background">
      <Navigation />

      {/* Hero Section */}
      <section className="pt-32 pb-16 relative">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-primary/10 via-background to-background" />
        <div className="relative z-10 mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 text-center">
          <Badge variant="secondary" className="mb-4">
            <Sparkles className="h-3 w-3 mr-1" />
            Transparent Pricing
          </Badge>
          <h1 className="font-[family-name:var(--font-display)] text-4xl sm:text-5xl font-bold mb-6">
            Simple, <span className="text-primary">Affordable</span> Pricing
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Choose a package that fits your needs. No hidden fees, no surprises — just great work at fair prices.
          </p>
        </div>
      </section>

      {/* Main Packages */}
      <section className="py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <h2 className="font-[family-name:var(--font-display)] text-2xl sm:text-3xl font-bold text-center mb-12">
            Project Packages
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {packages.map((pkg) => (
              <div
                key={pkg.name}
                className={`relative p-8 rounded-2xl border transition-all ${
                  pkg.highlighted
                    ? "bg-primary/5 border-primary/30 scale-105 shadow-lg shadow-primary/10"
                    : "bg-card/50 border-border/50 hover:border-primary/30"
                }`}
              >
                {pkg.highlighted && (
                  <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                    <Badge className="bg-primary text-primary-foreground px-4 py-1">
                      Best Value
                    </Badge>
                  </div>
                )}
                <div className="flex items-center gap-3 mb-4">
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                    pkg.highlighted ? "bg-primary/20" : "bg-secondary/50"
                  }`}>
                    <pkg.icon className={`h-6 w-6 ${pkg.highlighted ? "text-primary" : "text-muted-foreground"}`} />
                  </div>
                  <div>
                    <h3 className="font-[family-name:var(--font-display)] font-semibold text-lg">
                      {pkg.name}
                    </h3>
                    <p className="text-xs text-muted-foreground">{pkg.period}</p>
                  </div>
                </div>
                <div className="mb-4">
                  <span className="font-[family-name:var(--font-display)] text-4xl font-bold text-primary">
                    {pkg.price}
                  </span>
                </div>
                <p className="text-sm text-muted-foreground mb-6">{pkg.description}</p>
                <ul className="space-y-3 mb-8">
                  {pkg.features.map((feature) => (
                    <li key={feature} className="flex items-center gap-3 text-sm">
                      <Check className="h-4 w-4 text-primary shrink-0" />
                      {feature}
                    </li>
                  ))}
                </ul>
                <Button
                  className={`w-full ${
                    pkg.highlighted
                      ? "bg-primary text-primary-foreground hover:bg-primary/90"
                      : ""
                  }`}
                  variant={pkg.highlighted ? "default" : "outline"}
                  asChild
                >
                  <a href="https://discord.gg" target="_blank" rel="noopener noreferrer">
                    {pkg.cta}
                  </a>
                </Button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Bundles */}
      <section className="py-16 bg-card/30">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="font-[family-name:var(--font-display)] text-2xl sm:text-3xl font-bold mb-4">
              Curated Bundles
            </h2>
            <p className="text-muted-foreground max-w-xl mx-auto">
              Pre-packaged solutions for common needs. Save money while getting everything you need.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {bundles.map((bundle) => (
              <div
                key={bundle.name}
                className="group relative overflow-hidden rounded-2xl bg-card border border-border/50 hover:border-primary/30 transition-all"
              >
                <div className="relative h-32 overflow-hidden">
                  <img
                    src={bundle.image}
                    alt={bundle.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-card to-transparent" />
                  <Badge className="absolute top-4 right-4 bg-accent text-accent-foreground">
                    {bundle.savings}
                  </Badge>
                </div>
                <div className="p-6">
                  <h3 className="font-[family-name:var(--font-display)] text-lg font-semibold mb-1">
                    {bundle.name}
                  </h3>
                  <p className="text-sm text-muted-foreground mb-4">{bundle.description}</p>
                  <div className="space-y-2 mb-6">
                    {bundle.includes.map((item) => (
                      <div key={item} className="flex items-center gap-2 text-sm">
                        <Check className="h-4 w-4 text-primary shrink-0" />
                        {item}
                      </div>
                    ))}
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="font-[family-name:var(--font-display)] text-2xl font-bold text-primary">
                      {bundle.price}
                    </span>
                    <Button size="sm" asChild>
                      <a href="https://discord.gg" target="_blank" rel="noopener noreferrer">
                        Get Bundle
                      </a>
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Subscriptions */}
      <section className="py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-accent/10 border border-accent/30 mb-4">
              <Infinity className="h-4 w-4 text-accent" />
              <span className="text-sm font-medium text-accent">Monthly Plans</span>
            </div>
            <h2 className="font-[family-name:var(--font-display)] text-2xl sm:text-3xl font-bold mb-4">
              Ongoing Support Plans
            </h2>
            <p className="text-muted-foreground max-w-xl mx-auto">
              Need regular design and development work? Subscribe and save with our monthly plans.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
            {subscriptions.map((sub) => (
              <div
                key={sub.name}
                className={`relative p-6 rounded-2xl border transition-all ${
                  sub.popular
                    ? "bg-accent/5 border-accent/30"
                    : "bg-card/50 border-border/50 hover:border-accent/30"
                }`}
              >
                {sub.popular && (
                  <Badge className="absolute -top-3 left-1/2 -translate-x-1/2 bg-accent text-accent-foreground">
                    Recommended
                  </Badge>
                )}
                <h3 className="font-[family-name:var(--font-display)] font-semibold text-lg mb-2">
                  {sub.name}
                </h3>
                <div className="mb-4">
                  <span className="font-[family-name:var(--font-display)] text-3xl font-bold text-accent">
                    {sub.price}
                  </span>
                  <span className="text-muted-foreground">{sub.period}</span>
                </div>
                <ul className="space-y-2 mb-6">
                  {sub.features.map((feature) => (
                    <li key={feature} className="flex items-center gap-2 text-sm">
                      <Check className="h-4 w-4 text-accent shrink-0" />
                      {feature}
                    </li>
                  ))}
                </ul>
                <Button
                  variant={sub.popular ? "default" : "outline"}
                  className={`w-full ${sub.popular ? "bg-accent text-accent-foreground hover:bg-accent/90" : ""}`}
                  asChild
                >
                  <a href="https://discord.gg" target="_blank" rel="noopener noreferrer">
                    Subscribe
                  </a>
                </Button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-card/30">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="font-[family-name:var(--font-display)] text-2xl sm:text-3xl font-bold mb-4">
            Not Sure What You Need?
          </h2>
          <p className="text-muted-foreground mb-8 max-w-xl mx-auto">
            No problem! Join our Discord and tell us about your project. We will help you find the perfect solution for your budget.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Button size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90 gap-2" asChild>
              <a href="https://discord.gg" target="_blank" rel="noopener noreferrer">
                Chat With Us
                <ArrowRight className="h-4 w-4" />
              </a>
            </Button>
            <Button size="lg" variant="outline" asChild>
              <Link href="/services">View All Services</Link>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </main>
  )
}
