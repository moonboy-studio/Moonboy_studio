"use client"

import { useState } from "react"
import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"
import { ExternalLink, Globe, Palette, Film, MessageCircle, Sparkles } from "lucide-react"

const categories = [
  { id: "all", label: "All Projects", icon: Sparkles },
  { id: "web", label: "Websites", icon: Globe },
  { id: "design", label: "Design", icon: Palette },
  { id: "video", label: "Video", icon: Film },
  { id: "discord", label: "Discord", icon: MessageCircle },
]

const projects = [
  {
    id: 1,
    title: "Phoenix Esports Tournament",
    category: "web",
    client: "MLBB Tournament",
    description: "Custom tournament website with live bracket system, team registration, and admin panel.",
    features: ["Responsive UI", "Live Brackets", "Admin Dashboard"],
    image: "https://images.unsplash.com/photo-1542751371-adc38448a05e?w=800&q=80",
  },
  {
    id: 2,
    title: "Vanguard Gaming Rebrand",
    category: "design",
    client: "Esports Team",
    description: "Complete brand identity including logo, social media kit, and merchandise designs.",
    features: ["Logo Design", "Social Kit", "Brand Guide"],
    image: "https://images.unsplash.com/photo-1614680376593-902f74cf0d41?w=800&q=80",
  },
  {
    id: 3,
    title: "Apex Legends Montage",
    category: "video",
    client: "Content Creator",
    description: "High-energy gaming montage with motion graphics, synced to music.",
    features: ["Motion Graphics", "Color Grading", "Sound Design"],
    image: "https://images.unsplash.com/photo-1511512578047-dfb367046420?w=800&q=80",
  },
  {
    id: 4,
    title: "Tech Community Server",
    category: "discord",
    client: "Developer Community",
    description: "50,000+ member server with custom bots, verification, and moderation systems.",
    features: ["Custom Bots", "Auto-mod", "Ticket System"],
    image: "https://images.unsplash.com/photo-1614680376408-81e91ffe3db7?w=800&q=80",
  },
  {
    id: 5,
    title: "Indie Game Studio Site",
    category: "web",
    client: "Game Development",
    description: "Portfolio website showcasing games with trailers, press kits, and contact forms.",
    features: ["Video Integration", "Press Kit", "Dark Theme"],
    image: "https://images.unsplash.com/photo-1552820728-8b83bb6b2b0c?w=800&q=80",
  },
  {
    id: 6,
    title: "Weekly Tournament Series",
    category: "design",
    client: "Gaming Community",
    description: "Consistent weekly poster series for recurring tournaments with dynamic templates.",
    features: ["Template System", "Quick Turnaround", "Brand Consistency"],
    image: "https://images.unsplash.com/photo-1493711662062-fa541f7f3d24?w=800&q=80",
  },
  {
    id: 7,
    title: "Streamer Intro Package",
    category: "video",
    client: "Twitch Streamer",
    description: "Animated intro, outro, and transition pack for a variety streamer.",
    features: ["3D Animation", "Stinger Transitions", "Audio Design"],
    image: "https://images.unsplash.com/photo-1598550476439-6847785fcea6?w=800&q=80",
  },
  {
    id: 8,
    title: "NFT Project Server",
    category: "discord",
    client: "Web3 Community",
    description: "Launch server with whitelist system, role gating, and announcement automation.",
    features: ["Whitelist Bot", "Role Gating", "Auto Announcements"],
    image: "https://images.unsplash.com/photo-1639762681057-408e52192e55?w=800&q=80",
  },
  {
    id: 9,
    title: "Coaching Platform",
    category: "web",
    client: "Gaming Coach",
    description: "Booking platform for gaming coaching sessions with payment integration.",
    features: ["Booking System", "Payments", "User Accounts"],
    image: "https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=800&q=80",
  },
]

export default function PortfolioPage() {
  const [activeFilter, setActiveFilter] = useState("all")

  const filteredProjects = activeFilter === "all"
    ? projects
    : projects.filter((p) => p.category === activeFilter)

  return (
    <main className="min-h-screen bg-background">
      <Navigation />

      {/* Hero Section */}
      <section className="pt-32 pb-16 relative">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-primary/10 via-background to-background" />
        <div className="relative z-10 mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 text-center">
          <Badge variant="secondary" className="mb-4">
            <Sparkles className="h-3 w-3 mr-1" />
            Our Work
          </Badge>
          <h1 className="font-[family-name:var(--font-display)] text-4xl sm:text-5xl font-bold mb-6">
            Featured <span className="text-primary">Projects</span>
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Explore our portfolio of websites, designs, videos, and Discord setups created for gamers, creators, and businesses.
          </p>
        </div>
      </section>

      {/* Filter Tabs */}
      <section className="pb-8">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap justify-center gap-2">
            {categories.map((category) => (
              <Button
                key={category.id}
                variant={activeFilter === category.id ? "default" : "outline"}
                size="sm"
                onClick={() => setActiveFilter(category.id)}
                className={cn(
                  "gap-2 transition-all",
                  activeFilter === category.id
                    ? "bg-primary text-primary-foreground"
                    : "hover:bg-secondary/50"
                )}
              >
                <category.icon className="h-4 w-4" />
                {category.label}
              </Button>
            ))}
          </div>
        </div>
      </section>

      {/* Projects Grid */}
      <section className="py-12">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredProjects.map((project) => (
              <article
                key={project.id}
                className="group relative overflow-hidden rounded-2xl bg-card border border-border/50 hover:border-primary/30 transition-all duration-300"
              >
                {/* Image */}
                <div className="relative h-48 overflow-hidden">
                  <img
                    src={project.image}
                    alt={project.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-card via-card/50 to-transparent" />
                  
                  {/* Category Badge */}
                  <div className="absolute top-4 left-4">
                    <Badge variant="secondary" className="backdrop-blur-sm bg-background/70">
                      {categories.find((c) => c.id === project.category)?.label}
                    </Badge>
                  </div>

                  {/* Hover Overlay */}
                  <div className="absolute inset-0 bg-primary/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <Button size="sm" variant="secondary" className="gap-2">
                      <ExternalLink className="h-4 w-4" />
                      View Project
                    </Button>
                  </div>
                </div>

                {/* Content */}
                <div className="p-6">
                  <p className="text-xs text-primary font-medium mb-1">{project.client}</p>
                  <h3 className="font-[family-name:var(--font-display)] text-lg font-semibold mb-2 group-hover:text-primary transition-colors">
                    {project.title}
                  </h3>
                  <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
                    {project.description}
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {project.features.map((feature) => (
                      <span
                        key={feature}
                        className="px-2.5 py-1 text-xs font-medium rounded-full bg-secondary/50 text-muted-foreground"
                      >
                        {feature}
                      </span>
                    ))}
                  </div>
                </div>
              </article>
            ))}
          </div>

          {/* Empty State */}
          {filteredProjects.length === 0 && (
            <div className="text-center py-20">
              <p className="text-muted-foreground">No projects found in this category.</p>
            </div>
          )}
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-card/30">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="font-[family-name:var(--font-display)] text-2xl sm:text-3xl font-bold mb-4">
            Want to See Your Project Here?
          </h2>
          <p className="text-muted-foreground mb-8 max-w-xl mx-auto">
            Join our growing list of satisfied clients. Start your project today and let us bring your vision to life.
          </p>
          <Button size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90" asChild>
            <a href="https://discord.gg" target="_blank" rel="noopener noreferrer">
              Start Your Project
            </a>
          </Button>
        </div>
      </section>

      <Footer />
    </main>
  )
}
