import { Metadata } from "next"
import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Check, Globe, Palette, Film, MessageCircle, ArrowRight, Sparkles } from "lucide-react"

export const metadata: Metadata = {
  title: "Services | Moonboy Studio",
  description: "Website development, graphic design, video editing, and Discord server setup services for gamers and creators.",
}

const services = [
  {
    id: "web",
    icon: Globe,
    title: "Website Development",
    description: "Custom websites for tournaments, businesses, and portfolios. Mobile-friendly, modern UI, and fast deployment.",
    features: [
      "Custom responsive design",
      "Mobile-first approach",
      "SEO optimized",
      "Admin dashboard (if needed)",
      "Fast loading times",
      "Discord integration ready",
    ],
    tiers: [
      {
        name: "Basic",
        price: "$99",
        description: "Simple landing page or portfolio",
        delivery: "2-3 days",
        features: ["1-3 pages", "Mobile responsive", "Basic SEO", "1 revision"],
      },
      {
        name: "Standard",
        price: "$249",
        description: "Multi-page website with advanced features",
        delivery: "3-5 days",
        popular: true,
        features: ["5-10 pages", "Custom animations", "Contact forms", "3 revisions", "Basic CMS"],
      },
      {
        name: "Premium",
        price: "$499+",
        description: "Fully custom web application",
        delivery: "5-10 days",
        features: ["Unlimited pages", "Admin panel", "Database integration", "Unlimited revisions", "Priority support"],
      },
    ],
  },
  {
    id: "design",
    icon: Palette,
    title: "Poster / Graphic Design",
    description: "Eye-catching visuals for events, social media content, and complete branding kits.",
    features: [
      "Event & tournament posters",
      "Social media content packs",
      "Team logos & branding",
      "Stream overlays & panels",
      "Banner designs",
      "Brand style guides",
    ],
    tiers: [
      {
        name: "Basic",
        price: "$29",
        description: "Single design piece",
        delivery: "1-2 days",
        features: ["1 design", "2 concepts", "Source file", "1 revision"],
      },
      {
        name: "Standard",
        price: "$79",
        description: "Design pack for an event or campaign",
        delivery: "2-4 days",
        popular: true,
        features: ["3-5 designs", "Consistent style", "All source files", "3 revisions"],
      },
      {
        name: "Premium",
        price: "$199+",
        description: "Complete branding package",
        delivery: "4-7 days",
        features: ["Full brand kit", "Logo + variations", "Style guide", "Unlimited revisions", "Priority delivery"],
      },
    ],
  },
  {
    id: "video",
    icon: Film,
    title: "Video Editing",
    description: "Professional edits for short-form content, YouTube videos, and gaming montages.",
    features: [
      "TikTok & Reels edits",
      "YouTube video editing",
      "Gaming montages",
      "Highlight reels",
      "Intros & outros",
      "Motion graphics",
    ],
    tiers: [
      {
        name: "Basic",
        price: "$49",
        description: "Short-form content edit",
        delivery: "1-2 days",
        features: ["Up to 60 seconds", "Basic transitions", "Music sync", "1 revision"],
      },
      {
        name: "Standard",
        price: "$129",
        description: "YouTube or longer format edit",
        delivery: "3-5 days",
        popular: true,
        features: ["Up to 10 minutes", "Advanced effects", "Sound design", "3 revisions", "Thumbnails included"],
      },
      {
        name: "Premium",
        price: "$299+",
        description: "Full production editing",
        delivery: "5-10 days",
        features: ["Any length", "Motion graphics", "Color grading", "Unlimited revisions", "Rush delivery"],
      },
    ],
  },
  {
    id: "discord",
    icon: MessageCircle,
    title: "Discord Server Setup",
    description: "Complete server configuration with bots, automation, roles, channels, and security.",
    features: [
      "Full server architecture",
      "Bot setup & configuration",
      "Role hierarchy & permissions",
      "Auto-moderation setup",
      "Welcome systems",
      "Ticket & support systems",
    ],
    tiers: [
      {
        name: "Basic",
        price: "$39",
        description: "Essential server setup",
        delivery: "1-2 days",
        features: ["Channel structure", "Basic roles", "Welcome message", "1 bot setup"],
      },
      {
        name: "Standard",
        price: "$89",
        description: "Full-featured community server",
        delivery: "2-4 days",
        popular: true,
        features: ["Advanced channels", "Role rewards", "3+ bots", "Auto-mod", "Ticket system"],
      },
      {
        name: "Premium",
        price: "$179+",
        description: "Enterprise-grade server",
        delivery: "3-7 days",
        features: ["Custom bot development", "Advanced automation", "Security audit", "Documentation", "Ongoing support"],
      },
    ],
  },
]

export default function ServicesPage() {
  return (
    <main className="min-h-screen bg-background">
      <Navigation />
      
      {/* Hero Section */}
      <section className="pt-32 pb-16 relative">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-primary/10 via-background to-background" />
        <div className="relative z-10 mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 text-center">
          <Badge variant="secondary" className="mb-4">
            <Sparkles className="h-3 w-3 mr-1" />
            Our Services
          </Badge>
          <h1 className="font-[family-name:var(--font-display)] text-4xl sm:text-5xl font-bold mb-6">
            Everything You Need to{" "}
            <span className="text-primary">Build & Grow</span>
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            From websites to Discord servers, we provide comprehensive digital services tailored for gamers, creators, and businesses.
          </p>
        </div>
      </section>

      {/* Services Sections */}
      {services.map((service, serviceIndex) => (
        <section
          key={service.id}
          id={service.id}
          className={`py-20 ${serviceIndex % 2 === 1 ? "bg-card/30" : ""}`}
        >
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            {/* Service Header */}
            <div className="flex flex-col md:flex-row md:items-center gap-6 mb-12">
              <div className="w-16 h-16 rounded-2xl bg-primary/10 border border-primary/30 flex items-center justify-center shrink-0">
                <service.icon className="h-8 w-8 text-primary" />
              </div>
              <div>
                <h2 className="font-[family-name:var(--font-display)] text-2xl sm:text-3xl font-bold mb-2">
                  {service.title}
                </h2>
                <p className="text-muted-foreground max-w-2xl">
                  {service.description}
                </p>
              </div>
            </div>

            {/* Features Grid */}
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-12">
              {service.features.map((feature) => (
                <div
                  key={feature}
                  className="flex items-center gap-2 p-3 rounded-xl bg-secondary/30 border border-border/50"
                >
                  <Check className="h-4 w-4 text-primary shrink-0" />
                  <span className="text-sm">{feature}</span>
                </div>
              ))}
            </div>

            {/* Pricing Tiers */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {service.tiers.map((tier) => (
                <div
                  key={tier.name}
                  className={`relative p-6 rounded-2xl border transition-all ${
                    tier.popular
                      ? "bg-primary/5 border-primary/30 scale-105"
                      : "bg-card/50 border-border/50 hover:border-primary/30"
                  }`}
                >
                  {tier.popular && (
                    <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                      <Badge className="bg-primary text-primary-foreground">Most Popular</Badge>
                    </div>
                  )}
                  <div className="text-center mb-6">
                    <h3 className="font-[family-name:var(--font-display)] font-semibold text-lg mb-1">
                      {tier.name}
                    </h3>
                    <div className="font-[family-name:var(--font-display)] text-3xl font-bold text-primary mb-2">
                      {tier.price}
                    </div>
                    <p className="text-sm text-muted-foreground mb-2">{tier.description}</p>
                    <p className="text-xs text-muted-foreground">Delivery: {tier.delivery}</p>
                  </div>
                  <ul className="space-y-3 mb-6">
                    {tier.features.map((feature) => (
                      <li key={feature} className="flex items-center gap-2 text-sm">
                        <Check className="h-4 w-4 text-primary shrink-0" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                  <Button
                    className={`w-full ${
                      tier.popular
                        ? "bg-primary text-primary-foreground hover:bg-primary/90"
                        : ""
                    }`}
                    variant={tier.popular ? "default" : "outline"}
                    asChild
                  >
                    <a href="https://discord.gg" target="_blank" rel="noopener noreferrer">
                      Get Started
                    </a>
                  </Button>
                </div>
              ))}
            </div>
          </div>
        </section>
      ))}

      {/* CTA */}
      <section className="py-20">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="font-[family-name:var(--font-display)] text-2xl sm:text-3xl font-bold mb-4">
            Need a Custom Package?
          </h2>
          <p className="text-muted-foreground mb-8 max-w-xl mx-auto">
            We offer flexible pricing and can combine services to match your exact needs. Reach out on Discord to discuss your project.
          </p>
          <Button size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90 gap-2" asChild>
            <a href="https://discord.gg" target="_blank" rel="noopener noreferrer">
              Contact Us on Discord
              <ArrowRight className="h-4 w-4" />
            </a>
          </Button>
        </div>
      </section>

      <Footer />
    </main>
  )
}
