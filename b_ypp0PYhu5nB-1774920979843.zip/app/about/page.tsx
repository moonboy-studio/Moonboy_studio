import { Metadata } from "next"
import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Sparkles, Target, Eye, Code, Palette, Film, Users, ArrowRight, Heart } from "lucide-react"

export const metadata: Metadata = {
  title: "About Us | Moonboy Studio",
  description: "Learn about Moonboy Studio - a small, fast-moving team helping digital creators and businesses launch high-quality projects.",
}

const team = [
  {
    name: "Alex",
    role: "Lead Developer",
    icon: Code,
    description: "Full-stack developer specializing in modern web technologies and gaming platforms.",
    avatar: "A",
  },
  {
    name: "Jordan",
    role: "Creative Director",
    icon: Palette,
    description: "Visual designer with a passion for gaming aesthetics and brand identity.",
    avatar: "J",
  },
  {
    name: "Riley",
    role: "Video Editor",
    icon: Film,
    description: "Motion graphics expert creating engaging content for streamers and esports.",
    avatar: "R",
  },
  {
    name: "Sam",
    role: "Community Manager",
    icon: Users,
    description: "Discord specialist and community builder with experience in gaming communities.",
    avatar: "S",
  },
]

const values = [
  {
    title: "Speed",
    description: "We deliver fast without sacrificing quality. Your time matters.",
  },
  {
    title: "Quality",
    description: "Every project is crafted with attention to detail and modern standards.",
  },
  {
    title: "Community",
    description: "We understand gaming culture and build for the communities we love.",
  },
  {
    title: "Accessibility",
    description: "Professional services at prices that work for indie creators.",
  },
]

const timeline = [
  {
    year: "2023",
    title: "The Beginning",
    description: "Moonboy Studio started as a passion project, helping friends with their Discord servers and tournament websites.",
  },
  {
    year: "2024",
    title: "Growing Team",
    description: "Expanded our services and brought on talented designers and editors to serve more clients.",
  },
  {
    year: "2025",
    title: "50+ Projects",
    description: "Hit our milestone of 50 completed projects across web, design, video, and Discord services.",
  },
  {
    year: "Future",
    title: "Scaling Up",
    description: "Building the go-to digital agency for gamers and online communities worldwide.",
  },
]

export default function AboutPage() {
  return (
    <main className="min-h-screen bg-background">
      <Navigation />

      {/* Hero Section */}
      <section className="pt-32 pb-20 relative">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-primary/10 via-background to-background" />
        <div className="relative z-10 mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl">
            <Badge variant="secondary" className="mb-4">
              <Sparkles className="h-3 w-3 mr-1" />
              About Us
            </Badge>
            <h1 className="font-[family-name:var(--font-display)] text-4xl sm:text-5xl font-bold mb-6">
              A Small Team with{" "}
              <span className="text-primary">Big Dreams</span>
            </h1>
            <p className="text-lg text-muted-foreground leading-relaxed mb-8">
              Moonboy Studio is a small, fast-moving team helping digital creators and businesses launch high-quality projects without the hassle. We are gamers, creators, and developers who understand what you need.
            </p>
          </div>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-20 bg-card/30">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="p-8 rounded-2xl bg-card border border-border/50">
              <div className="w-12 h-12 rounded-xl bg-primary/10 border border-primary/30 flex items-center justify-center mb-6">
                <Target className="h-6 w-6 text-primary" />
              </div>
              <h2 className="font-[family-name:var(--font-display)] text-2xl font-bold mb-4">
                Our Mission
              </h2>
              <p className="text-muted-foreground leading-relaxed">
                To make high-quality digital services accessible, fast, and community-driven. We believe every creator deserves professional-grade tools and designs, regardless of their budget.
              </p>
            </div>
            <div className="p-8 rounded-2xl bg-card border border-border/50">
              <div className="w-12 h-12 rounded-xl bg-accent/10 border border-accent/30 flex items-center justify-center mb-6">
                <Eye className="h-6 w-6 text-accent" />
              </div>
              <h2 className="font-[family-name:var(--font-display)] text-2xl font-bold mb-4">
                Our Vision
              </h2>
              <p className="text-muted-foreground leading-relaxed">
                To become the go-to digital agency for gamers and online communities. We want to be the first call when a tournament needs a website or a creator needs a brand refresh.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="font-[family-name:var(--font-display)] text-2xl sm:text-3xl font-bold mb-4">
              What We <span className="text-primary">Stand For</span>
            </h2>
            <p className="text-muted-foreground max-w-xl mx-auto">
              Our core values guide every project we take on and every interaction we have.
            </p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {values.map((value) => (
              <div
                key={value.title}
                className="p-6 rounded-2xl bg-card/50 border border-border/50 hover:border-primary/30 transition-colors text-center"
              >
                <h3 className="font-[family-name:var(--font-display)] font-semibold text-lg mb-2 text-primary">
                  {value.title}
                </h3>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {value.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Team */}
      <section className="py-20 bg-card/30">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="font-[family-name:var(--font-display)] text-2xl sm:text-3xl font-bold mb-4">
              Meet the <span className="text-primary">Team</span>
            </h2>
            <p className="text-muted-foreground max-w-xl mx-auto">
              A small but mighty crew of passionate creators and developers.
            </p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {team.map((member) => (
              <div
                key={member.name}
                className="group p-6 rounded-2xl bg-card border border-border/50 hover:border-primary/30 transition-all text-center"
              >
                <div className="w-20 h-20 mx-auto rounded-full bg-primary/10 border-2 border-primary/30 flex items-center justify-center mb-4 group-hover:border-primary/60 transition-colors">
                  <span className="font-[family-name:var(--font-display)] text-2xl font-bold text-primary">
                    {member.avatar}
                  </span>
                </div>
                <h3 className="font-[family-name:var(--font-display)] font-semibold text-lg mb-1">
                  {member.name}
                </h3>
                <div className="flex items-center justify-center gap-2 text-sm text-primary mb-3">
                  <member.icon className="h-4 w-4" />
                  {member.role}
                </div>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {member.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Timeline */}
      <section className="py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="font-[family-name:var(--font-display)] text-2xl sm:text-3xl font-bold mb-4">
              Our <span className="text-primary">Journey</span>
            </h2>
            <p className="text-muted-foreground max-w-xl mx-auto">
              From a passion project to a growing digital agency.
            </p>
          </div>
          <div className="relative">
            {/* Timeline Line */}
            <div className="absolute left-0 md:left-1/2 top-0 bottom-0 w-px bg-border/50 -translate-x-1/2 hidden md:block" />
            
            <div className="space-y-12">
              {timeline.map((item, index) => (
                <div
                  key={item.year}
                  className={`relative flex flex-col md:flex-row gap-8 ${
                    index % 2 === 0 ? "md:flex-row" : "md:flex-row-reverse"
                  }`}
                >
                  <div className="md:w-1/2 md:text-right">
                    {index % 2 === 0 && (
                      <div className={`${index % 2 === 0 ? "md:pr-12" : "md:pl-12"}`}>
                        <span className="font-[family-name:var(--font-display)] text-4xl font-bold text-primary">
                          {item.year}
                        </span>
                        <h3 className="font-[family-name:var(--font-display)] text-xl font-semibold mt-2 mb-2">
                          {item.title}
                        </h3>
                        <p className="text-muted-foreground">{item.description}</p>
                      </div>
                    )}
                  </div>
                  <div className="absolute left-0 md:left-1/2 w-4 h-4 rounded-full bg-primary border-4 border-background -translate-x-1/2 hidden md:block" style={{ top: "0.5rem" }} />
                  <div className="md:w-1/2">
                    {index % 2 === 1 && (
                      <div className={`${index % 2 === 1 ? "md:pl-12" : "md:pr-12"}`}>
                        <span className="font-[family-name:var(--font-display)] text-4xl font-bold text-primary">
                          {item.year}
                        </span>
                        <h3 className="font-[family-name:var(--font-display)] text-xl font-semibold mt-2 mb-2">
                          {item.title}
                        </h3>
                        <p className="text-muted-foreground">{item.description}</p>
                      </div>
                    )}
                  </div>
                  {/* Mobile View */}
                  <div className="md:hidden pl-8 border-l-2 border-primary/30">
                    <span className="font-[family-name:var(--font-display)] text-2xl font-bold text-primary">
                      {item.year}
                    </span>
                    <h3 className="font-[family-name:var(--font-display)] text-lg font-semibold mt-1 mb-1">
                      {item.title}
                    </h3>
                    <p className="text-sm text-muted-foreground">{item.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-card/30">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8 text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/30 mb-6">
            <Heart className="h-4 w-4 text-primary" />
            <span className="text-sm font-medium text-primary">Join Our Community</span>
          </div>
          <h2 className="font-[family-name:var(--font-display)] text-2xl sm:text-3xl font-bold mb-4">
            Ready to Work Together?
          </h2>
          <p className="text-muted-foreground mb-8 max-w-xl mx-auto">
            Join our Discord community to discuss your project, get support, or just hang out with fellow gamers and creators.
          </p>
          <Button size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90 gap-2" asChild>
            <a href="https://discord.gg" target="_blank" rel="noopener noreferrer">
              Join Our Discord
              <ArrowRight className="h-4 w-4" />
            </a>
          </Button>
        </div>
      </section>

      <Footer />
    </main>
  )
}
